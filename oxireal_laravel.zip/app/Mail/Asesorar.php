<?php

namespace App\Mail;

use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Queue\SerializesModels;
use Illuminate\Bus\Queueable;
use Illuminate\Mail\Mailable;

class Asesorar extends Mailable

{
    use Queueable, SerializesModels;

    public function __construct($nombre, $email, $empresa, $mensaje)

    {
        $this->nombre = $nombre;
        $this->email = $email;
        $this->empresa = $empresa;
        $this->mensaje = $mensaje;
    }

    public function build()

    {
        return $this->view('page.sendasesorar')->with([
                        'nombre' => $this->nombre,
                        'email' => $this->email,
                        'empresa' => $this->empresa,
                        'mensaje' => $this->mensaje    
                        ]);

    }

}

