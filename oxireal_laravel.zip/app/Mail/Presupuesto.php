<?php

namespace App\Mail;

use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Queue\SerializesModels;
use Illuminate\Bus\Queueable;
use Illuminate\Mail\Mailable;

class Presupuesto extends Mailable

{
    use Queueable, SerializesModels;

    public function __construct($nombre, $localidad, $email, $telefono, $mensaje, $file_save)

    {
        $this->nombre = $nombre;
        $this->localidad = $localidad;
        $this->email = $email;
        $this->telefono = $telefono;
        $this->mensaje = $mensaje;
        $this->file_save = $file_save;
    }

    public function build()
    {
        return $this->view('page.sendpresupuesto')->with([
                        'nombre' => $this->nombre,
                        'localidad' => $this->localidad,
                        'email' => $this->email,
                        'telefono' => $this->telefono,
                        'mensaje' => $this->mensaje
                        ])->attach(public_path().'/images/adjuntos/'.$this->file_save);

    }

}
