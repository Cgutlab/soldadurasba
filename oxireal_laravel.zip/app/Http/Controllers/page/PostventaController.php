<?php

namespace App\Http\Controllers\page;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Postventa;
use App\Metadato;

class PostventaController extends Controller
{
    public function index()
    {
    	$metadato = Metadato::where('section','postventa')->first();
    	$active = 'postventa';
    	$postventas = Postventa::orderBy('order', 'ASC')->get();
    	return view('page.postventa',compact('sliders', 'metadato', 'active', 'postventas'));
    }
}
