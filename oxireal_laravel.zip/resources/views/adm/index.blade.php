@extends('adm.main')



@section('titulo', 'Bienvenido')



@section('cuerpo')

    

@endsection