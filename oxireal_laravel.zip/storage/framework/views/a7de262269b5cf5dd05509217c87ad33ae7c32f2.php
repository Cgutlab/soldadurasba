<?php $__env->startSection('titulo', 'Editar contenido de calidad'); ?>

<?php $__env->startSection('cuerpo'); ?>

<main>
	<div class="container">
	    <?php if(count($errors) > 0): ?>
		<div class="col s12 card-panel red lighten-4 red-text text-darken-4">
	  		<ul>
	  			<?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
	  				<li><?php echo $error; ?></li>
	  			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	  		</ul>
	  	</div>
		<?php endif; ?>
		<?php if(session('success')): ?>
		<div class="col s12 card-panel green lighten-4 green-text text-darken-4">
			<?php echo e(session('success')); ?>

		</div>
		<?php endif; ?>

		<div class="row">
			<div class="col s12">
			<?php echo Form::model($calidad, ['route'=>['calidad.update', $calidad->id], 'method'=>'PUT', 'files' => true]); ?>

				<div class="row">
			      	<label class="col s12" for="titulo">Título</label>
			      	<div class="input-field col s12">
						<?php echo Form::text('title', $calidad->title, ['class'=>'validate']); ?>

				    </div>
				</div>
				<div class="row">
			      	<label class="col s12" for="texto">Texto</label>
			      	<div class="input-field col s12">
						<?php echo Form::textarea('text', $calidad->text, ['class'=>'validate', 'cols'=>'74', 'rows'=>'5']); ?>

				    </div>
				</div>
				<div class="row">
					<div class="file-field input-field col s6">
					    <div class="btn">
					        <span>Política de calidad</span>
					        <?php echo Form::file('politic'); ?>

					    </div>
					    <div class="file-path-wrapper">
					      	<?php echo Form::text('',null, ['class'=>'file-path validate']); ?>

					    </div>
					</div>
				</div>
				
				<div class="col s12 no-padding">
					<?php echo Form::submit('Guardar', ['class'=>'waves-effect waves-light btn right']); ?>

				</div>
				<?php echo Form::close(); ?> 
				</div>
			</div>
		</div>
	</div>
</main>
<script src="//cdn.ckeditor.com/4.7.3/full/ckeditor.js"></script>
<script>
	CKEDITOR.replace('text');
	CKEDITOR.config.height = '300px';
	CKEDITOR.config.width = '100%';
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('adm.main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>