<?php $__env->startSection('titulo', 'Crear slider'); ?>

<?php $__env->startSection('cuerpo'); ?>
	<main>
		<div class="container">
		    <?php if(count($errors) > 0): ?>
			<div class="col s12 card-panel red lighten-4 red-text text-darken-4">
		  		<ul>
		  			<?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		  				<li><?php echo $error; ?></li>
		  			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		  		</ul>
		  	</div>
			<?php endif; ?>
				<?php if(session('success')): ?>
					<div class="col s12 card-panel green lighten-4 green-text text-darken-4">
						<?php echo e(session('success')); ?>

					</div>
				<?php endif; ?>
			<?php
				$section = 'home';
			?>

			<div class="row">
				<div class="col s12">
					<?php echo Form::open(['route'=>'slider.store', 'method'=>'POST', 'files' => true]); ?>

						<div class="row">
					      	<div class="input-field col s12">
					      		<?php echo Form::label('title','Título'); ?>

								<?php echo Form::text('title', null, ['class'=>'validate', 'cols'=>'74', 'rows'=>'5']); ?>

						    </div>
						</div>
						<div class="row">
					      	<div class="input-field col s12">
					      		<?php echo Form::label('subtitle','Subtítulo'); ?>

								<?php echo Form::text('subtitle', null, ['class'=>'validate', 'cols'=>'74', 'rows'=>'5']); ?>

						    </div>
						</div>
						<div class="row">
							<div class="file-field input-field col s6">
								<div class="btn">
								    <span>Imagen</span>
								    <?php echo Form::file('image'); ?>

								</div>
								<div class="file-path-wrapper">
								    <?php echo Form::text('',null, ['class'=>'file-path validate']); ?>

								</div>
								<small>Tamaño recomendado 1474 x 549</small>
							</div>
							<div class="input-field col s6">
								<?php echo Form::label('order','Orden'); ?>

								<?php echo Form::text('order',null,['class'=>'validate', 'required']); ?>

							</div>
						</div>
						<?php echo Form::hidden('section',$section); ?>

						<div class="col s12 no-padding">
							<?php echo Form::submit('Crear', ['class'=>'waves-effect waves-light btn right']); ?>

						</div>
					<?php echo Form::close(); ?> 
				</div>
			</div>
		</div>
	</main>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('adm.main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>