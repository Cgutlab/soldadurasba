<!DOCTYPE html>
<html lang="es">
<head>	
	<meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <?php $__currentLoopData = $metadatos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $metadato): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
	    <meta name="description" content="<?php echo e($metadato->description); ?>">
	    <meta name="keyword" content="<?php echo e($metadato->keyword); ?>">
   	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	<title>Aceros San Jorge ~ Calidad</title>
	<?php echo $__env->make('page.template.links', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
	<link rel="stylesheet" href="<?php echo e(asset('css/calidad.css')); ?>">
</head>
<body>
	<?php echo $__env->make('page.template.header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<main class="calidad">
	<div class="banner mb10">
		<img src="<?php echo e(asset('images/banners/'.$banner->image)); ?>" alt="">
		<div class="texto fs32 blanco bold"><?php echo $banner->title; ?></div>
	</div>
	<div class="container mt60">
		<div class="row">
			<div class="col l6 fs19 gris texto">
				<?php echo $calidad->text; ?>

			</div>
			<div class="col l6 naranja fs33 titulo">
				<?php echo $calidad->title; ?>

				<div class="linea-amarilla mt20"></div>
			</div>
			<div class="col s12">
				<div class="mb70 mt30 bloque">
					<a class="naranja" href="<?php echo e(asset('images/calidad/'.$calidad->politic)); ?>" download="Política_de_calidad" target="_blank">
						<i class="material-icons">file_download</i><span class="gris">Política de calidad</span>
					</a>
				</div>
			</div>
		</div>
	</div>
</main>


	<?php echo $__env->make('page.template.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

	<?php echo $__env->make('page.template.scripts', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

</body>
</html>