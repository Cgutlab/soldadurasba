<!DOCTYPE html>
<html lang="es">
<head>
	
	<meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="<?php echo e($metadato->description); ?>">
    <meta name="keyword" content="<?php echo e($metadato->keyword); ?>">
	<title>Oxireal ~ Familias</title>
	<?php echo $__env->make('page.template.links', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
	<link rel="stylesheet" href="<?php echo e(asset('css/producto.css')); ?>">
</head>
<body>
	<?php echo $__env->make('page.template.header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
	<main class="familia">
		<div class="banner valign-wrapper">
			<div class="container width85">
				<div class="titulo bold fs35">productos</div>
			</div>
		</div>
		<div class="container width85 mt50 mb20">
			<div class="row">
				<?php $__currentLoopData = $familias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $familia): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<a href="<?php echo e(route('subfamilia',$familia->id)); ?>" class="gris">
						<div class="col s12 m3 mb30">
							<div class="card z-depth-0">
						        <div class="card-image">
						        	<div class="efecto">
			                        	<span class="central"><i class="material-icons">add</i></span>
			                    	</div>
						          	<img src="<?php echo e(asset('images/familias/'.$familia->image)); ?>">
						        </div>
						        <div class="card-content centrar">
						          	<div class="fs22 center-align"><?php echo $familia->title; ?></div>
						        </div>
					      	</div>
						</div>
					</a>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			</div>
		</div>
	</main>


	<?php echo $__env->make('page.template.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

	<?php echo $__env->make('page.template.scripts', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

</body>
</html>