<!DOCTYPE html>
<html lang="es">
<head>
	<meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <?php $__currentLoopData = $metadatos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $metadato): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
	    <meta name="description" content="<?php echo e($metadato->description); ?>">
	    <meta name="keyword" content="<?php echo e($metadato->keyword); ?>">
   	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	<title>Aceros San Jorge ~ Fundición</title>
	<?php echo $__env->make('page.template.links', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
	<link rel="stylesheet" href="<?php echo e(asset('css/fundicion.css')); ?>">
</head>
<body>
	<?php echo $__env->make('page.template.header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<main class="fundicion">
	<div class="banner mb60">
		<img src="<?php echo e(asset('images/banners/'.$banner->image)); ?>" alt="">
		<div class="texto fs32 blanco bold"><?php echo $banner->title; ?></div>
	</div>
	<div class="container mb60">
		<div class="row">
			<?php $__currentLoopData = $fundiciones; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $fundicion): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				<div class="col s6 m3 mb20">
			      	<div class="card z-depth-0">
			        	<div class="card-image mb10">
				          	<img src="<?php echo e(asset('images/fundicion/'.$fundicion->image)); ?>">
			        	</div>
			        	<div class="card-content">
			          		<div class="fs22 naranja"><?php echo $fundicion->title; ?></div>
			          		<div style="overflow: hidden;height: 90px;"><?php echo $fundicion->text; ?></div>
			        	</div>
			        </div>
			    </div>
			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		</div>
	</div>
	<div class="contacto center-align">
		<div class="container">
			<?php if(session('error')): ?>
				<div class="col s12 card-panel red lighten-4 red-text text-darken-4">
					<?php echo e(session('error')); ?>

				</div>
			<?php endif; ?>
			<?php if(session('success')): ?>
				<div class="col s12 card-panel green lighten-4 green-text text-darken-4">
					<?php echo e(session('success')); ?>

				</div>
			<?php endif; ?> 
		</div>
		<div class="row">
			<div class="fs27 naranja pt60 mb10"><?php echo $texto->title; ?></div>
			<div class="fs17 gris mb10"><?php echo $texto->text; ?></div>
				<?php echo Form::open(['route' => 'asesorar.enviar', 'method' => 'POST']); ?>

					<div class="container">
						<div class="input-field col s12">
							<?php echo Form::text('nombre',null,['class' => 'validate', 'placeholder' => 'Nombre']); ?>

						</div>
						<div class="input-field col s12">
							<?php echo Form::email('email',null,['class' => 'validate', 'placeholder' => 'Correo']); ?>

						</div>
						<div class="input-field col s12">
							<?php echo Form::text('empresa',null,['class' => 'validate', 'placeholder' => 'Empresa']); ?>

						</div>
						<div class="input-field col s12">
							<?php echo Form::textarea('mensaje', null, ['class'=>'materialize-textarea', 'placeholder'=>'Mensaje', 'required']); ?>

						</div>
						<div class="input-field col s12 m6">
							<div class="g-recaptcha" data-sitekey="6Le4WT4UAAAAAMsSrRvyvdMGIEyHIXLmuf9EFYPl"></div>
						</div>
						<div class="input-field col s12 m6 push-m1 mb10">
							<div>
								<a href="#modal1" class="modal-trigger" style="font-size: 12px; color:#494949; text-decoration: underline;">Acepto los términos y condiciones de privacidad</a>
      						</div>
						</div>
						<div class="col s12">
							<button class="btn waves-effect waves-light z-depth-0 mb60 mt20 bg-naranja" type="submit" name="action">Enviar</button>
						</div>
					</div>
				<?php echo Form::close(); ?>

		</div>
	</div>


	<!-- Modal Structure -->
  	<div id="modal1" class="modal">
    	<div class="modal-content">
      		<h4><?php echo $legal->title; ?></h4>
      		<p><?php echo $legal->text; ?></p>
    	</div>
    	<div class="modal-footer">
      		<a href="#!" class="modal-close waves-effect btn-flat">Acepto</a>
    	</div>
  	</div>

</main>


	<?php echo $__env->make('page.template.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

	<?php echo $__env->make('page.template.scripts', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
	<script src='https://www.google.com/recaptcha/api.js'></script>
<script>
  	$(document).ready(function(){
  		$('.modal').modal();
  	});
</script>
</body>
</html>