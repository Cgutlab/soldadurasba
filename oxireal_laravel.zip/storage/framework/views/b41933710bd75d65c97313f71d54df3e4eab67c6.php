<header>	
	<div class="z-depth-0 row hide-on-med-and-down" style="padding: 30px 0 10px;">
		<div class="container" style="width: 85%;">
			<div class="row centrado">
				<div class="col s6">
		      		<a href="<?php echo e(route('home')); ?>" class="brand-logo"><img src="<?php echo e(asset('images/logos/'. $logoh->image)); ?>"></a>
		      	</div>
		      	<div class="col offset-s4 s3 right centrado" style="justify-content: space-between;">
		      		<?php echo Form::open(['route'=> 'buscador', 'method' => 'post', 'class' => 'buscador']); ?>

	                    <button type="submit"><i class="fas fa-search" style="margin-right: 10px;"></i></button>
			      		<input type="search" name="busqueda" placeholder="Estoy buscando..." autocomplete="off" style="margin-bottom: 15px;">
		      		<?php echo Form::close(); ?>

		      	</div>
	      	</div>
		</div>
	</div>
	<nav class="header z-depth-0 centrar">
		<div class="container">
		    <div class="nav-wrapper">
		      	<ul id="nav-mobile" class="hide-on-med-and-down">
		      		<li class="<?php if($active === 'empresa'): ?> activo <?php endif; ?>"><a class="centrado" href="<?php echo e(route('empresa')); ?>">Quiénes Somos</a></li>
		      		<li class="menu-global relative <?php if($active === 'producto'): ?> activo <?php endif; ?>"><a class="centrado" href="<?php echo e(route('familia')); ?>">Productos</a>
						<ul class="menu-padre">
							<?php $__currentLoopData = $familis; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
								<a class="gris" href="<?php echo e(route('subfamilia',$item->id)); ?>" style="color:#595959;height: initial; font-size: 14px;">
									<li class="gris fs14 left relative" style="border: none; position: relative;"><?php echo $item->title; ?>

								</a>
										<ul class="menu-hijo">
											<?php $__currentLoopData = $subfamilis; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subitem): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
												<?php if($item->id == $subitem->family_id): ?>
													<a class="gris" href="<?php echo e(route('productos',$subitem->id)); ?>">
													<li class="gris fs14 left" style="border: none;"><?php echo $subitem->title; ?></li>
												<?php endif; ?>
											<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
										</ul>
									</li>
								<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
							</ul>


		      		</li>
		      		<li class="<?php if($active === 'garantia'): ?> activo <?php endif; ?>"><a class="centrado" href="<?php echo e(route('garantia')); ?>">Garantía</a></li>
                    <li class="<?php if($active === 'postventa'): ?> activo <?php endif; ?>"><a class="centrado" href="<?php echo e(route('postventa')); ?>">Post-Venta</a></li>
                    <li class="<?php if($active === 'descarga'): ?> activo <?php endif; ?>"><a class="centrado" href="<?php echo e(route('descarga')); ?>">Descargas</a></li>
                    <li class="<?php if($active === 'contacto'): ?> activo <?php endif; ?>"><a class="centrado" href="<?php echo e(route('contacto')); ?>">Contacto</a></li>
                    <li class="no-hover"><a class="centrado" href='tel:<?php echo e($celular->description); ?>' style="border-left: 1px solid #43B4FF"><i class="gris-claro <?php echo e($celular->image); ?>" style="margin-right: 10px; font-size: 14px;"></i><?php echo e($celular->description); ?></a></li>
                </ul>
            </div>
        </div>
    </nav>
</header>

