	<link href="<?php echo e(asset('css/materialize/materialize.min.css')); ?>" rel="stylesheet">

    <link href="<?php echo e(asset('css/estilos.css')); ?>" rel="stylesheet">

    <link href="<?php echo e(asset('css/estilo.css')); ?>" rel="stylesheet">
    <link rel="shortcut icon" href="<?php echo e(asset('images/logos/favicon.png')); ?>" type="image/png">
    <link rel="icon" href="<?php echo e(asset('images/logos/favicon.png')); ?>" type="image/png">

	<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.2.0/css/all.css" integrity="sha384-hWVjflwFxL6sNzntih27bfxkr27PmbbK/iSvJ+a4+0owXq79v+lsFkW54bOGbiDQ" crossorigin="anonymous">

    <!--Import Google Icon Font-->
	
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">

    <link href="https://fonts.googleapis.com/css?family=Titillium+Web:300,400,600,700,900" rel="stylesheet">