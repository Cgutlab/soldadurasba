<?php $__env->startSection('titulo', 'Editar galerias'); ?>

<?php $__env->startSection('cuerpo'); ?>
	<main>
		<div class="container">
		    <?php if(count($errors) > 0): ?>
			<div class="col s12 card-panel red lighten-4 red-text text-darken-4">
		  		<ul>
		  			<?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		  				<li><?php echo $error; ?></li>
		  			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		  		</ul>
		  	</div>
			<?php endif; ?>
			<?php if(session('success')): ?>
				<div class="col s12 card-panel green lighten-4 green-text text-darken-4">
					<?php echo e(session('success')); ?>

				</div>
			<?php endif; ?>

			<div class="row">
				<div class="col s12">
					<table class="highlight bordered">
						<a href="<?php echo e(route('productogaleria.create')); ?>"><div class="right nuevo"><i class="material-icons">add</i>Nueva imagen</div></a>
						<thead>
							<td>Imagen</td>
							<td>Orden</td>
							<td class="text-right">Acciones</td>
						</thead>
						<tbody>
							<?php $__currentLoopData = $galerias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $galeria): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
								<tr>
									<td><img class="slider-foto" src="<?php echo e(asset("images/galeria/".$galeria->image)); ?>" width="100"></td>
									<td><?php echo $galeria->order; ?></td>
									<td class="text-right">
										<a href="<?php echo e(route('productogaleria.edit',$galeria->id)); ?>"><i title="Editar" class="material-icons">create</i></a>
										<?php echo Form::open(['class'=>'en-linea', 'route'=>['productogaleria.destroy', $galeria->id], 'method' => 'DELETE']); ?>

											<button type="submit" class="submit-button confirmar">
												<i title="Eliminar" class="material-icons red-text">cancel</i>
											</button>
										<?php echo Form::close(); ?>

									</td>
								</tr>
							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						</tbody>
					</table>			
				</div>
			</div>
	    </div>
	</main>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('adm.main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>