<header>	
	<div class="nav z-depth-0 row hide-on-med-and-down">
		<div class="container">
			<div class="right center-align">
				<ul>
					<li class="centrado <?php if($active==='presupuesto'): ?> activoup <?php endif; ?>""><a href="<?php echo e(route('presupuesto')); ?>">SOLICITAR PRESUPUESTO</a></li>
					<li class="centrado <?php if($active==='contacto'): ?> activoup <?php endif; ?>"><a href="<?php echo e(route('contacto')); ?>">CONTACTO</a></li>
					<?php $__currentLoopData = $hredes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $hred): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<li class="blanco centrado sociales-up"><a class="enlaces" href="<?php echo e($hred->route); ?>" target="_blank"><img src="<?php echo e(asset('images/redes/'. $hred->image)); ?>" alt=""></a></li>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					<li class="bg-naranja"><a class="buscar blanco" href="<?php echo e(route('buscar')); ?>"><i class="material-icons blanco">search</i></a></li>
				</ul>
			</div>
		</div>
	</div>
	<nav class="header z-depth-0">
		<div class="container">
		    <div class="nav-wrapper">
		      	<a href="<?php echo e(route('home')); ?>" class="brand-logo center"><img class="responsive-img" src="<?php echo e(asset('images/logos/'. $logoh->image)); ?>"></a>
		      	<ul id="nav-mobile" class="left hide-on-med-and-down valign-wrapper">
		      		<li><a class="centrado <?php if($active==='empresa'): ?> activo <?php endif; ?>" href="<?php echo e(route('empresa')); ?>">EMPRESA</a></li>
		      		<li><a class="centrado <?php if($active==='fundicion'): ?> activo <?php endif; ?>" href="<?php echo e(route('fundicion')); ?>">FUNDICIÓN</a></li>
		      		<li><a class="centrado <?php if($active==='piezas'): ?> activo <?php endif; ?>" href="<?php echo e(route('pieza')); ?>">PIEZAS TERMINADAS</a></li>
		      	</ul>
		      	<ul id="nav-mobile" class="right hide-on-med-and-down valign-wrapper">
		      		<li><a class="centrado <?php if($active==='trabajos'): ?> activo <?php endif; ?>" href="<?php echo e(route('trabajo')); ?>">TRABAJOS REALIZADOS</a></li>
		      		<li><a class="centrado <?php if($active==='clientes'): ?> activo <?php endif; ?>" href="<?php echo e(route('cliente')); ?>">CLIENTES</a></li>
		      		<li><a class="centrado <?php if($active==='calidad'): ?> activo <?php endif; ?>" href="<?php echo e(route('calidad')); ?>">CALIDAD</a></li>
		      	</ul>
		    </div>
		</div>
	</nav>
</header>
	