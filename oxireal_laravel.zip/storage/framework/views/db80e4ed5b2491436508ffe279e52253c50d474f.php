<!DOCTYPE html>
<html lang="es">
<head>
	
	<meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="<?php echo e($metadato->description); ?>">
    <meta name="keyword" content="<?php echo e($metadato->keyword); ?>">
	<title>Oxireal ~ Garantía</title>
	<?php echo $__env->make('page.template.links', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
	<link rel="stylesheet" href="<?php echo e(asset('css/garantia.css')); ?>">
</head>
<body>
	<?php echo $__env->make('page.template.header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
	<main class="garantia">
		<div class="banner valign-wrapper">
			<div class="container width85">
				<div class="titulo bold fs35">post-venta</div>
			</div>
		</div>
		<div class="container width85 mt20 mb70">
			<div class="row">
				<?php $__currentLoopData = $postventas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $postventa): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<div class="col s12 l6 mt50" style="height: 150px;">
						<div class="row">
							<div class="col s12 m2 center">
								<img src="<?php echo e(asset('images/postventa/'.$postventa->image)); ?>" alt="">
							</div>
							<div class="col s12 m10">
								<div class="gris bold fs25" style="line-height: 1;"><?php echo $postventa->title; ?></div>
								<div class="gris-claro fs20"><?php echo $postventa->subtitle; ?></div>
								<div><?php echo $postventa->text; ?></div>
							</div>
						</div>
					</div>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			</div>
		</div>
		<div class="bg-gris-claro" style="border-top: 1px solid #DDD;">
			<div class="container width85">
				<?php if(session('error')): ?>
					<div class="col s12 card-panel red lighten-4 red-text text-darken-4">
						<?php echo e(session('error')); ?>

					</div>
				<?php endif; ?>
				<?php if(session('success')): ?>
					<div class="col s12 card-panel green lighten-4 green-text text-darken-4">
						<?php echo e(session('success')); ?>

					</div>
				<?php endif; ?> 
				<div class="row center-align">
					<div class="fs27 azul pt60 mb10">¿Necesitás Asesoramiento?</div>
					<div class="fs17 gris mb10">Completá el siguiente formulario y nos contactaremos a la brevedad</div>
						<?php echo Form::open(['method' => 'POST']); ?>

							<div class="container">
								<div class="container">
									<div class="input-field col s12">
										<?php echo Form::text('nombre',null,['class' => 'validate', 'placeholder' => 'Nombre', 'autocomplete' => 'off']); ?>

									</div>
									<div class="input-field col s12">
										<?php echo Form::email('email',null,['class' => 'validate', 'placeholder' => 'Email', 'autocomplete' => 'off']); ?>

									</div>
									<div class="input-field col s12">
										<?php echo Form::text('empresa',null,['class' => 'validate', 'placeholder' => 'Empresa', 'autocomplete' => 'off']); ?>

									</div>
									<div class="input-field col s12">
										<?php echo Form::textarea('mensaje', null, ['class'=>'materialize-textarea', 'placeholder'=>'Mensaje', 'required']); ?>

									</div>
									<div class="input-field col s12 m6">
										<div class="g-recaptcha" data-sitekey="6Le4WT4UAAAAAMsSrRvyvdMGIEyHIXLmuf9EFYPl"></div>
									</div>
									<div class="input-field col s12 m6 push-m1 mb10">
										
									</div>
									<div class="col s12">
										<button class="btn waves-effect waves-light z-depth-0 mb60 mt20" type="submit" name="action">Enviar</button>
									</div>
								</div>
							</div>
						<?php echo Form::close(); ?>

				</div>
			</div>
		</div>
	</main>


	<?php echo $__env->make('page.template.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

	<?php echo $__env->make('page.template.scripts', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

</body>
</html>