<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Garantia extends Model
{
    protected $fillable = [
    	'title', 'text', 'image',
    ];
}
