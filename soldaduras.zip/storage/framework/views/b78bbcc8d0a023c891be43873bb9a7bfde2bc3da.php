<!DOCTYPE html>
<html lang="es">
<head>
	
	<meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="<?php echo e($metadato->description); ?>">
    <meta name="keyword" content="<?php echo e($metadato->keyword); ?>">
	<title>Soldaduras Buenos Aires ~ Descargas</title>
	<?php echo $__env->make('page.template.links', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
	<link rel="stylesheet" href="<?php echo e(asset('css/descarga.css')); ?>">
</head>
<body>
	<?php echo $__env->make('page.template.header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
	<main class="descarga">
		<div class="banner valign-wrapper">
			<div class="container width85">
				<div class="titulo bold fs35">descarga</div>
			</div>
		</div>
		<div class="container width85 mt50 mb50">
			<div class="row">
				<?php $__currentLoopData = $descargas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $descarga): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<a class="gris" href="<?php echo e(asset('images/descargas/'.$descarga->route)); ?>" download="">
						<div class="col s12 m6 l4">
							<div class="center">
								<img src="<?php echo e(asset('images/descargas/descarga.jpg')); ?>" alt="">
							</div>
							<div class="center-align">
								<div class="center"><i class="material-icons amarillo">file_download</i><?php echo $descarga->title; ?></div>
							</div>
						</div>
					</a>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			</div>
		</div>
	</main>


	<?php echo $__env->make('page.template.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

	<?php echo $__env->make('page.template.scripts', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

</body>
</html>