<!DOCTYPE html>
<html lang="es">
<head>
	<meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <?php $__currentLoopData = $metadatos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $metadato): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
	    <meta name="description" content="<?php echo e($metadato->description); ?>">
	    <meta name="keyword" content="<?php echo e($metadato->keyword); ?>">
   	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	<title>Aceros San Jorge ~ Busqueda</title>
	<link rel="stylesheet" href="<?php echo e(asset('css/buscar.css')); ?>">
	<?php echo $__env->make('page.template.links', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
</head>
<body>
	<?php echo $__env->make('page.template.header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<main class="buscar mb70">
	<div class="container">
		<nav class="z-depth-0 mt70 mb50 busqueda">
	    	<div class="nav-wrapper z-depth-0">
	      		<?php echo Form::open(['route'=>'buscador', 'method' => 'POST']); ?>

                    <div class="input-field">
                        <input id="busqueda" name="busqueda" type="search" placeholder="Buscar" required>
                        <label class="label-icon" for="search"><i class="material-icons">search</i></label>
                        <i class="material-icons">chevron_right</i>
                    </div>
	      		<?php echo Form::close(); ?>

	    	</div>
	  	</nav>
      	<div class="row">
            <?php if($busca==1): ?>
                <?php $__currentLoopData = $trabajos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $trabajo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <a href="<?php echo e(route('trabajo')); ?>">
                        <div class="col s12 m6 l4">
                            <div class="card z-depth-0">
                                <div class="card-image">
                                    <img src="<?php echo e(asset('images/trabajo/'. $trabajo->image)); ?>">
                                </div>
                            <div class="card-content center-align bold mayus naranja fs18 centrado">
                                <?php echo e($trabajo->title); ?>

                            </div>
                          </div>
                        </div>
                    </a>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php $__currentLoopData = $fundiciones; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $fundicion): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <a href="<?php echo e(route('fundicion')); ?>">
                        <div class="col s12 m6 l4">
                            <div class="card z-depth-0">
                                <div class="card-image">
                                    <img src="<?php echo e(asset('images/fundicion/'. $fundicion->image)); ?>">
                                </div>
                            <div class="card-content center-align bold mayus naranja fs18 centrado">
                                <?php echo e($fundicion->title); ?>

                            </div>
                          </div>
                        </div>
                    </a>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php $__currentLoopData = $piezas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pieza): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <a href="<?php echo e(route('pieza')); ?>">
                        <div class="col s12 m6 l4">
                            <div class="card z-depth-0">
                                <div class="card-image">
                                    <img src="<?php echo e(asset('images/pieza/'. $pieza->image)); ?>">
                                </div>
                            <div class="card-content center-align bold mayus naranja fs18 centrado">
                                <?php echo e($pieza->title); ?>

                            </div>
                          </div>
                        </div>
                    </a>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endif; ?>
        </div>
    </div>
</main>
<?php echo $__env->make('page.template.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php echo $__env->make('page.template.scripts', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
</body>
</html>