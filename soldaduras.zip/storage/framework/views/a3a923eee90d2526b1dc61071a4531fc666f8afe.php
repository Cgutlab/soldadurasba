<!DOCTYPE html>
<html lang="es">
<head>
	
	<meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="<?php echo e($metadato->description); ?>">
    <meta name="keyword" content="<?php echo e($producto->keyword); ?>">
	<title>Soldaduras Buenos Aires ~ <?php echo $producto->name; ?></title>
	<?php echo $__env->make('page.template.links', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
	<link rel="stylesheet" href="<?php echo e(asset('css/producto.css')); ?>">
</head>
<body>
	<?php echo $__env->make('page.template.header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
	<main class="familia">
		<div class="banner valign-wrapper">
			<div class="container width85">
				<div class="titulo bold fs35">productos</div>
			</div>
		</div>
		<div class="container width85 mt10">
			<div class="fs18 gris"><a class="gris" href="<?php echo e(route('familia')); ?>">Productos </a>| <a class="gris" href="<?php echo e(route('subfamilia',$producto->subfamilia->familia->id)); ?>"><?php echo e($producto->subfamilia->familia->title); ?> |</a> <a class="gris" href="<?php echo e(route('productos',$producto->subfamilia->id)); ?>"><?php echo $producto->subfamilia->title; ?></a> | <?php echo $producto->name; ?></div>
		</div>
		<div class="container width85 mt50 mb50">
			<div class="row">
				<div class="col s12 m6">
					<div class="slider">
					    <ul class="slides">
				            <li>
                				<img src="<?php echo e(asset('images/productos/'.$producto->image)); ?>" alt="">
                			</li>
					    </ul>
					</div>					
				</div>
				<div class="col s12 m6">
					<div class="gris-oscuro">
						<div class="gris bold fs30"><?php echo $producto->name; ?></div>
						<?php if($producto->code): ?><div class="fs16 gris-claro">Código <?php echo $producto->code; ?></div><?php endif; ?>
						<div class="linea mt10" style="background-color: #ffab00!important;"></div>
						<div><?php echo $producto->descripcion; ?></div>
						<?php if($producto->pdf): ?><button class="btn">Ficha Técnica</button><?php endif; ?>
					</div>
				</div>
			</div>
			<?php if($producto->video): ?>
				<div class="row mt30">
					<div class="col s12 bg-gris-claro" style="padding: 1.50rem;">
						<div class="row valign-wrapper">
							<div class="col s6 bold fs18 gris">
								<div>Para más información mira el video a continuación</div>
							</div>
							<div class="col s6">
								<iframe src="https://www.youtube.com/embed/<?php echo $producto->video; ?>" controls="on" width="100%" height="300"></iframe>
							</div>
						</div>
					</div>
				</div>
			<?php endif; ?>
			<div class="row">
				<div class="amarillo fs25 mt30">Productos Relacionados</div>
				<div class="linea mb30"></div>
				<?php $__currentLoopData = $producto->productos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $relacionado): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <a class="gris-oscuro" href="<?php echo e(route('producto', $relacionado->id)); ?>">
                       <div class="col s12 m3 mb30">
							<div class="card z-depth-0">
						        <div class="card-image">
						        	<div class="efecto">
			                        	<span class="central"><i class="material-icons">add</i></span>
			                    	</div>
						          	<img src="<?php echo e(asset('images/productos/'.$relacionado->image)); ?>">
						        </div>
						        <div class="card-content centrar">
						          	<div class="fs18 center-align"><?php echo $relacionado->name; ?></div>
						        </div>
					      	</div>
						</div>
                    </a>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
			</div>
		</div>
	</main>


	<?php echo $__env->make('page.template.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

	<?php echo $__env->make('page.template.scripts', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

</body>
</html>