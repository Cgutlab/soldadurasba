<!DOCTYPE html>
<html lang="es">
<head>
	
	<meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="<?php echo e($metadato->description); ?>">
    <meta name="keyword" content="<?php echo e($metadato->keyword); ?>">
	<title>Oxireal ~ Empresa</title>
	<?php echo $__env->make('page.template.links', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
	<link rel="stylesheet" href="<?php echo e(asset('css/empresa.css')); ?>">
</head>
<body>
	<?php echo $__env->make('page.template.header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<main class="empresa">
	<div class="slider">
	    <ul class="slides">
	        <?php $__currentLoopData = $sliders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $slider): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
	            <li>
	                <img src="<?php echo e(asset('images/sliders/'.$slider->image)); ?>">
	                <div class="caption">
	                    <div class="fs52 bold blanco no-margin" style="line-height: 1;"><?php echo $slider->title; ?></div>
	                    <div class="fs22 lighter blanco gris-oscuro mt10"><?php echo $slider->subtitle; ?></div>
	                </div>
	            </li>
	        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	    </ul>
	</div>
	<div class="container mt50 mb50 width85">
		<div class="row">
			<div class="col s12 l4">
				<img class="responsive-img" src="<?php echo e(asset('images/empresa/'.$empresa->image)); ?>">
			</div>
			<div class="col s12 l8">
				<div class="fs32 azul"><?php echo $empresa->title; ?></div>
				<div class="linea"></div>
				<div><?php echo $empresa->text; ?></div>
			</div>
		</div>
	</div>
</main>


	<?php echo $__env->make('page.template.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

	<?php echo $__env->make('page.template.scripts', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

</body>
</html>