<!DOCTYPE html>
<html lang="es">
<head>	
	<meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <?php $__currentLoopData = $metadatos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $metadato): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
	    <meta name="description" content="<?php echo e($metadato->description); ?>">
	    <meta name="keyword" content="<?php echo e($metadato->keyword); ?>">
   	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	<title>Aceros San Jorge ~ Trabajos realizados</title>
	<?php echo $__env->make('page.template.links', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
	<link rel="stylesheet" href="<?php echo e(asset('css/trabajo.css')); ?>">
	<link rel="stylesheet" type="text/css" href="slick/slick.css"/>
	<link rel="stylesheet" type="text/css" href="slick/slick-theme.css"/>

</head>
<body>
	<?php echo $__env->make('page.template.header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<main class="trabajo">
	<div class="banner mb70">
		<img src="<?php echo e(asset('images/banners/'.$banner->image)); ?>" alt="">
		<div class="texto fs32 blanco bold"><?php echo $banner->title; ?></div>
	</div>
	<div class="container mb70">
		<div class="row">
			<?php $__currentLoopData = $trabajos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $trabajo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				<div class="col s12 m6 mb20">
			      	<div class="card z-depth-0">
			      		<a class="gris modal-trigger" href="<?php echo e('#modal'.$trabajo->id); ?>">
				        	<div class="card-image">
				        		<div class="efecto">
			                        <span class="central"><i class="material-icons">add</i></span>
			                    </div>
					          	<img src="<?php echo e(asset('images/trabajo/'.$trabajo->image)); ?>">
				        	</div>
				        	<div class="card-content">
				          		<div class="fs17 gris centrado"><?php echo $trabajo->title; ?></div>
				        	</div>
			        	</a>
			        </div>
			    </div>
			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		</div>
	</div>
	<?php $__currentLoopData = $trabajos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $trabajo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		<div id="<?php echo e('modal'.$trabajo->id); ?>" class="modal">
		    <div class="modal-footer">
		      	<a href="#!" class="modal-close waves-effect btn-flat">Cerrar X</a>
		    </div>
		    <div class="modal-content container">
		      	<h4 class="center-align naranja fs18 mb20"><?php echo $trabajo->title; ?></h4>
						<div class="mb10">
							<img  id="imgDisp" src="<?php echo e(asset('images/trabajo/'.$trabajo->image)); ?>" alt="">
						</div>
			</div>
			<div class="container">
				<div class="row mb20">
					<div class="col s4">
						<img class="responsive-img" class="imgName" src="<?php echo e(asset('images/trabajo/'.$trabajo->image)); ?>" alt="" width="150">
					</div>
					<?php $__currentLoopData = $galerias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $galeria): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<?php if($galeria->trabajo_id == $trabajo->id): ?>
							<div class="col s4">
								<img class="responsive-img" class="imgName" src="<?php echo e(asset('images/trabajo/'.$galeria->image)); ?>" alt="" width="150">
							</div>
						<?php endif; ?>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				</div>
			<p class="mt20"><?php echo $trabajo->text; ?></p>      	
			</div>	
		</div>
	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</main>


	<?php echo $__env->make('page.template.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
	<?php echo $__env->make('page.template.scripts', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
	<script type="text/javascript" src="<?php echo e(asset('slick/slick.min.js')); ?>"></script>
	<script type="text/javascript">
		$(document).ready(function(){
    		$('.modal').modal();
    		$('.carousel').carousel();
    	});
	</script>
	<script type="text/javascript">
    	function changeImage(imgName)
        {
            image = document.getElementById('imgDisp');
            image.src = imgName;
        }
</script>
</body>
</html>