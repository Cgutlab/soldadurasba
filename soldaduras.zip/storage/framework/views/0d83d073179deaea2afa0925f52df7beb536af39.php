<!DOCTYPE html>
<html lang="es">
<head>
	
	<meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <?php $__currentLoopData = $metadatos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $metadato): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
	    <meta name="description" content="<?php echo e($metadato->description); ?>">
	    <meta name="keyword" content="<?php echo e($metadato->keyword); ?>">
   	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	<title>Aceros San Jorge ~ Home</title>
	<?php echo $__env->make('page.template.links', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
	<link rel="stylesheet" href="<?php echo e(asset('css/home.css')); ?>">
</head>
<body>
	<?php echo $__env->make('page.template.header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<main class="home">
	
	<div class="slider">
	    <ul class="slides">
	        <?php $__currentLoopData = $sliders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $slider): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
	            <li>
	                <img src="<?php echo e(asset('images/sliders/'.$slider->image)); ?>">
	                <div class="caption">
	                    <h2 class="mayus fs23 amarillo no-margin"><?php echo $slider->title; ?></h2>
	                    <h4 class="fs68"><?php echo $slider->subtitle; ?></h4>
	                </div>
	            </li>
	        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	    </ul>
	</div>
	<div class="container destacados mt20 mb50">
		<div class="row">
			<?php $__currentLoopData = $destacados; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $destacado): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				<?php if($destacado->id == 1): ?>
					<div class="col l8 no-right-padding relativo"><a href="<?php echo e(route('fundicion')); ?>"><div class="naranja fs35 texto"><?php echo $destacado->title; ?><div class="texto-gris">+ VER MÁS</div></div><img src="<?php echo e(asset('images/destacados/'.$destacado->image)); ?>" alt="" class="responsive-img"></a></div>
				<?php endif; ?>
				<?php if($destacado->id == 2): ?>
					<div class="col l4 relativo"><a href="<?php echo e(route('pieza')); ?>"><div class="naranja fs35 texto"><?php echo $destacado->title; ?><div class="texto-gris">+ VER MÁS</div></div><img src="<?php echo e(asset('images/destacados/'.$destacado->image)); ?>" alt="" class="responsive-img"></a></div>
				<?php endif; ?>
				<?php if($destacado->id == 3): ?>
					<div class="col l4 no-right-padding relativo"><a href="<?php echo e(route('presupuesto')); ?>"><div class="naranja fs35 texto"><?php echo $destacado->title; ?><div class="texto-gris">+ VER MÁS</div></div><img src="<?php echo e(asset('images/destacados/'.$destacado->image)); ?>" alt="" class="responsive-img"></a></div>
				<?php endif; ?>
				<?php if($destacado->id == 4): ?>
					<div class="col l8 no-left-padding relativo"><a href="<?php echo e(route('contacto')); ?>"><div class="naranja fs35 texto"><?php echo $destacado->title; ?><div class="texto-gris">+ VER MÁS</div></div><img src="<?php echo e(asset('images/destacados/'.$destacado->image)); ?>" alt="" class="responsive-img"></a></div>
				<?php endif; ?>
			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		</div>
	</div>
	<div style="background: url(<?php echo e(asset('images/home/'.$texto->image)); ?>); background-size: cover;">
		<div class="container">
			<div class="row centrado">
				<div class="col l2 naranja fs32 push-l1 no-margin"><?php echo $texto->title; ?></div>
				<div class="col l6 blanco fs21 pull-l1"><?php echo $texto->text; ?></div>
			</div>
		</div>
	</div>
</main>


	<?php echo $__env->make('page.template.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

	<?php echo $__env->make('page.template.scripts', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<script>
  	$(document).ready(function(){
  		$('.slider').slider();
  	});
</script>
</body>
</html>