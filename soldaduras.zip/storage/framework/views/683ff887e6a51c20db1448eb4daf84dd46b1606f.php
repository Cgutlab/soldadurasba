 <footer>
    <div class="container">
        <div class="row">
            <div class="col s12 l3">
                <div class="col s12">
                    <img src="<?php echo e(asset('images/logos/'. $logof->image)); ?>" alt="">
                </div>
                <div class="col s12 left blanco fs17">
                    <span style="margin-left: 20px;">Seguinos en <?php $__currentLoopData = $redesf; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $redf): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> <a class="blanco" href="<?php echo e($redf->route); ?>" target="__blank" style="margin-left: 10px;"><i class="blanco no-margin <?php echo e($redf->image); ?>"></i> </a> <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></span>
                </div>
            </div>
    	   	<div class="col s12 l6">
                <div class="col s4">
                    <ul class="sitemap">
                        <li><a href="<?php echo e(route('empresa')); ?>">Quiénes somos</a></li>
                        <li><a href="">Productos</a></li>
                    </ul>
                </div>  
                <div class="col s4">
                    <ul class="sitemap">
                        <li><a href="<?php echo e(route('garantia')); ?>">Garantía</a></li>
                        <li><a href="<?php echo e(route('postventa')); ?>">Post-venta</a></li>
                    </ul>
                </div>
                <div class="col s4">
                    <ul class="sitemap">
                        <li><a href="<?php echo e(route('descarga')); ?>">Descargas</a></li>
                        <li><a href="<?php echo e(route('contacto')); ?>">Contacto</a></li>
                    </ul>
                </div>
    	    </div>
           
        	<div class="col s12 l3">
                <div class="item-footer row blanco">
                    <div class="col l9 lighter mb15">
                        <div class="row">
                            <a href="" class="blanco">
                                <div class="col s1">    
                                    <i class="<?php echo e($ubicacion->image); ?>" style="color:#0074AE;"></i>
                                </div>
                                <div class="col s10 blanco">
                                    <?php echo e($ubicacion->description); ?>

                                </div>
                            </a>
                        </div>
                    </div>
                </div>
                <div class="item-footer row blanco">
                    <div class="col l9 lighter mb15">
                        <div class="row">
                            <a href="" class="blanco">
                                <div class="col s1">    
                                    <i class="<?php echo e($telefono->image); ?>" style="color:#0074AE;"></i>
                                </div>
                                <div class="col s10 blanco">
                                    <?php echo e($telefono->description); ?>

                                </div>
                            </a>
                        </div>
                    </div>
                </div>
                <div class="item-footer row blanco">
                    <div class="col l9 lighter mb15">
                        <div class="row">
                            <a href="" class="blanco">
                                <div class="col s1">    
                                    <i class="<?php echo e($correo->image); ?>" style="color:#0074AE;"></i>
                                </div>
                                <div class="col s10 blanco">
                                    <?php echo e($correo->description); ?>

                                </div>
                            </a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="linea" style="opacity: 0.3;"></div>
        <div class="blanco right mt10 mb10" style="opacity: 0.3;">By Osole</div>
    </div>
</footer>