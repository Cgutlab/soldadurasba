

<?php $__env->startSection('titulo', 'Crear red social'); ?>

<?php $__env->startSection('cuerpo'); ?>

<main>
	<div class="container">
	    <?php if(count($errors) > 0): ?>
		<div class="col s12 card-panel red lighten-4 red-text text-darken-4">
	  		<ul>
	  			<?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
	  				<li><?php echo $error; ?></li>
	  			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	  		</ul>
	  	</div>
		<?php endif; ?>
		<?php if(session('success')): ?>
		<div class="col s12 card-panel green lighten-4 green-text text-darken-4">
			<?php echo e(session('success')); ?>

		</div>
		<?php endif; ?>

		<div class="row">
            <div class="col s12">
				<?php echo Form::open(['route'=>'redes.store', 'method'=>'POST', 'files' => true]); ?>

					<div class="row">
						<div class="input-field col s6">
							<?php echo Form::label('name','Nombre'); ?>

							<?php echo Form::text('name',null,['class'=>'validate', 'required']); ?>

						</div>
						<div class="input-field col s6">
							<?php echo Form::label('route','Enlace'); ?>

							<?php echo Form::text('route',null,['class'=>'validate', 'required']); ?>

						</div>
						<div class="input-field col s6">
							<?php echo Form::label('image','Icono'); ?>

							<?php echo Form::text('image',null,['class'=>'validate', 'required']); ?>

						</div>
						<div class="input-field col s6">
							<?php echo Form::label('order','Orden'); ?>

							<?php echo Form::text('order',null,['class'=>'validate', 'required']); ?>

						</div>
						<div class="file-field input-field col s6">
					    	<?php echo Form::Select('section',[''=>'Sección...', 'header'=>'header', 'footer'=>'footer']); ?>

						</div>
					</div>
					<?php echo Form::submit('crear', ['class'=>'waves-effect waves-light btn right']); ?>

				<?php echo Form::close(); ?> 
			</div>
		</div>
	</div>
</main>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('adm.main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>