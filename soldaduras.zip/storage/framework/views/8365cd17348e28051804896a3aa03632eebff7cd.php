



<?php $__env->startSection('titulo', 'Bienvenido'); ?>



<?php $__env->startSection('cuerpo'); ?>

    

<?php $__env->stopSection(); ?>
<?php echo $__env->make('adm.main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>