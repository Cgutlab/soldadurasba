 <footer>
    <div class="container">
        <div class="row">
            <div class="col s12 l4 center-align mt20">
                <img src="<?php echo e(asset('images/logos/'. $logof->image)); ?>" alt="">
            </div>
    	   	<div class="col s12 l5">
    	       	<h6 class="amarillo fs16 bold">SITEMAP</h6>
                    <ul class="sitemap">
                <div class="row">
                    <div class="col l5">
                        <li><a href="<?php echo e(route('home')); ?>">Home</a></li>
                        <li><a href="<?php echo e(route('empresa')); ?>">Empresa</a></li>
                        <li><a href="<?php echo e(route('fundicion')); ?>">Fundición</a></li>
                        <li><a href="<?php echo e(route('pieza')); ?>">Piezas Terminadas</a></li>
                        <li><a href="<?php echo e(route('trabajo')); ?>">Trabajos Realizados</a></li>		  
                    </div>
                    <div class="col l6">
                        <li><a href="<?php echo e(route('cliente')); ?>">Clientes</a></li>
                        <li><a href="<?php echo e(route('calidad')); ?>">Calidad</a></li>
                        <li><a href="<?php echo e(route('presupuesto')); ?>">Solicitud de Presupuestos</a></li>
                        <li><a href="<?php echo e(route('contacto')); ?>">Contacto</a></li>
                    </div>
                </div>
                    </ul>
    	    </div>
        	<div class="col s12 l3">
                <h6 class="amarillo mayus fs16 bold">ACERÍAS SAN JORGE</h6>
                <div class="item-footer row blanco">
                    <div class="col l9 lighter mb15"><?php echo e($ubicacion->description); ?></div>
                </div>
                <div class="item-footer row blanco">
                    <div class="col l10 lighter mb15"><?php echo e($telefono->description); ?></div>
                </div>
                <div class="item-footer row blanco">
                    <div class="col l10 lighter mb15"><?php echo e($correo->description); ?></div>
                </div>
                 <?php $__currentLoopData = $fredes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $fred): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <span><a class="enlaces social" href="<?php echo e($fred->route); ?>" target="_blank"><img src="<?php echo e(asset('images/redes/'. $fred->image)); ?>" alt=""></a></span>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </div>
</footer>