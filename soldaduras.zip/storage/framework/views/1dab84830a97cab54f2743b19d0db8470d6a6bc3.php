	<link href="<?php echo e(asset('css/materialize/materialize.min.css')); ?>" rel="stylesheet">

    <link href="<?php echo e(asset('css/estilos.css')); ?>" rel="stylesheet">

    <link href="<?php echo e(asset('css/estilo.css')); ?>" rel="stylesheet">

	<link rel="shortcut icon" href="<?php echo e(asset('favicon.ico')); ?>" type="image/x-icon">

	<link rel="icon" href="<?php echo e(asset('favicon.ico')); ?>" type="image/x-icon"> 

	<script src="https://use.fontawesome.com/c3d13979f5.js"></script>

    <!--Import Google Icon Font-->

    <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">

    <link href="https://fonts.googleapis.com/css?family=Titillium+Web:300,400,600" rel="stylesheet">