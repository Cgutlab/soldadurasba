<script type="text/javascript" src="<?php echo e(asset('js/jquery.min.js')); ?>"></script>

<script type="text/javascript" src="<?php echo e(asset('js/materialize/materialize.min.js')); ?>"></script>

<script src="https://use.fontawesome.com/c3d13979f5.js"></script>
<script>
  	$(document).ready(function(){  
  		$('.dropdown-trigger').dropdown();
  		$('.slider').slider();
  		$('select').material_select(); 

  	}); 

  	 $('.dropdown-trigger').click(function(event) {
            {
  				$('#dropdown1').toggle();
            }
        });


</script>