<!DOCTYPE html>
<html lang="es">
<head>
	
	<meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <?php $__currentLoopData = $metadatos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $metadato): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
	    <meta name="description" content="<?php echo e($metadato->description); ?>">
	    <meta name="keyword" content="<?php echo e($metadato->keyword); ?>">
   	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	<title>Aceros San Jorge ~ Clientes</title>
	<?php echo $__env->make('page.template.links', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
	<link rel="stylesheet" href="<?php echo e(asset('css/cliente.css')); ?>">
</head>
<body>
	<?php echo $__env->make('page.template.header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<main class="cliente">
	<div class="banner mb10">
		<img src="<?php echo e(asset('images/banners/'.$banner->image)); ?>" alt="">
		<div class="texto fs32 blanco bold"><?php echo $banner->title; ?></div>
	</div>
	<div class="container">
		<div class="gris-claro fs19"><?php echo $texto->text; ?></div>
		<div class="row">
			<?php $__currentLoopData = $clientes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cliente): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				<div class="col s12 m6 l4 mb20">
					<a class="gris-claro" href="<?php echo $cliente->route; ?>">
				      	<div class="card z-depth-0">
				        	<div class="card-image">
					          	<img class="responsive-img" src="<?php echo e(asset('images/cliente/'.$cliente->image)); ?>">
				        	</div>
				        	<div class="card-content">
				          		<div class="fs17 gris-claro mayus center-align"><?php echo $cliente->title; ?></div>
				        	</div>
				        </div>
			        </a>
			    </div>
			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		</div>
	</div>
</main>


	<?php echo $__env->make('page.template.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

	<?php echo $__env->make('page.template.scripts', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

</body>
</html>