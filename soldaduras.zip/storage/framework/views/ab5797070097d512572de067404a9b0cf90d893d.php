<header>	
	<div class="z-depth-0 row" style="padding: 30px 0 10px;">
		<div class="container" style="width: 85%;">
			<div class="row centrado">
				<div class="col s12 m12 l6">
		      		<a href="<?php echo e(route('home')); ?>" class="brand-logo"><img src="<?php echo e(asset('images/logos/'. $logoh->image)); ?>"></a>
		      	</div>
		      	<div class="col offset-s4 s2 fs18 centrado hide-on-med-and-down" style="padding-right: 30px;">
		      		<a class="gris-claro" href="mailto:<?php echo e($correo->description); ?>">
		      			<?php echo e($correo->description); ?>

		      		</a>
		      	</div>
		      	<div class="col s3 right centrado hide-on-med-and-down" style="justify-content: space-between; border-left: 1px solid #DDD;">
		      		<?php echo Form::open(['route'=> 'buscador', 'method' => 'post', 'class' => 'buscador']); ?>

	                    <button type="submit"><i class="fas fa-search" style="margin-right: 10px;"></i></button>
			      		<input type="search" name="busqueda" placeholder="Estoy buscando..." autocomplete="off" style="margin-bottom: 15px;">
		      		<?php echo Form::close(); ?>

		      	</div>
	      	</div>
		</div>
	</div>
	<nav class="header z-depth-0 centrar hide-on-med-and-down" style="background:url(<?php echo e(asset('images/cabecera_metal_2.jpg')); ?>);">
		<div class="container">
		    <div class="nav-wrapper">
		      	<ul id="nav-mobile" class="">
		      		<li class="<?php if($active === 'empresa'): ?> activo <?php endif; ?>"><a class="centrado" href="<?php echo e(route('empresa')); ?>">Quiénes Somos</a></li>
		      		<li class="menu-global relative <?php if($active === 'producto'): ?> activo <?php endif; ?>"><a class="centrado" href="<?php echo e(route('familia')); ?>">Productos</a>
						<ul class="menu-padre">
							<?php $__currentLoopData = $familis; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
								<a class="gris" href="<?php echo e(route('subfamilia',$item->id)); ?>" style="color:#595959;height: initial; font-size: 14px;">
									<li class="gris fs14 left relative" style="border: none; position: relative;"><?php echo $item->title; ?>

								</a>
										
									</li>
								<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
							</ul>
					</li>
		      		<li class="<?php if($active === 'garantia'): ?> activo <?php endif; ?>"><a class="centrado" href="<?php echo e(route('garantia')); ?>">Garantía</a></li>
                    <li class="<?php if($active === 'postventa'): ?> activo <?php endif; ?>"><a class="centrado" href="<?php echo e(route('postventa')); ?>">Post-Venta</a></li>
                    <li class="<?php if($active === 'descarga'): ?> activo <?php endif; ?>"><a class="centrado" href="<?php echo e(route('descarga')); ?>">Descargas</a></li>
                    <li class="<?php if($active === 'contacto'): ?> activo <?php endif; ?>"><a class="centrado" href="<?php echo e(route('contacto')); ?>">Contacto</a></li>
                    <li class="no-hover"><a class="centrado"><i class="blanco <?php echo e($celular->image); ?>" style="margin-right: 10px;color:#FFF; font-size: 16px;"></i><?php echo e($celular->description); ?></a></li>
                </ul>
            </div>
        </div>
    </nav>
</header>

