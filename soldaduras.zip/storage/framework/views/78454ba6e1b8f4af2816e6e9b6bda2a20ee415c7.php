

<?php $__env->startSection('titulo', 'Selección de familia'); ?>

<?php $__env->startSection('cuerpo'); ?>

<main>
	<div class="container">
		<?php if(count($errors) > 0): ?>
			<div class="col s12 card-panel red lighten-4 red-text text-darken-4">
		  		<ul>
		  			<?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		  				<li><?php echo $error; ?></li>
		  			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		  		</ul>
		  	</div>
		<?php endif; ?>
		<?php if(session('success')): ?>
			<div class="col s12 card-panel green lighten-4 green-text text-darken-4">
				<?php echo e(session('success')); ?>

			</div>
		<?php endif; ?>
		
		<div class="row">
            <div class="col s12">
				<?php echo Form::open(['route'=>'producto.subfamilia.show', 'method'=>'POST', 'files' => true]); ?>

					<div class="row">
						<div class="input-field col s6">
							<select name="family_id">
								<option value=""> -- Selecciona una familia --</option>
									<?php $__currentLoopData = $familias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $familia): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
										<option value="<?php echo e($familia->id); ?>"><?php echo e($familia->title); ?></option>
									<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
							</select>
						</div>
					</div>
				<div class="col s12 no-padding">
					<?php echo Form::submit('Filtrar', ['class'=>'waves-effect waves-light btn right']); ?>

				</div>
				<?php echo Form::close(); ?> 
			</div>
		</div>
	</div>
</main>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('adm.main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>