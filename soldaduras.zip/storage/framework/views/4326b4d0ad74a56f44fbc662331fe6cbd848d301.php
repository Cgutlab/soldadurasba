<!DOCTYPE html>
<html lang="es">
<head>
	
	<meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <?php $__currentLoopData = $metadatos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $metadato): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
	    <meta name="description" content="<?php echo e($metadato->description); ?>">
	    <meta name="keyword" content="<?php echo e($metadato->keyword); ?>">
   	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	<title>Aceros San Jorge ~ Solicitud de presupuesto</title>
	<?php echo $__env->make('page.template.links', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/3.5.2/animate.min.css">
	<link rel="stylesheet" href="<?php echo e(asset('css/presupuesto.css')); ?>">
</head>
<body>
	<?php echo $__env->make('page.template.header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<main class="presupuesto">
	<div class="container mt70">
		<div class="row">
			<?php if(session('error')): ?>
				<div class="col s12 card-panel red lighten-4 red-text text-darken-4">
					<?php echo e(session('error')); ?>

				</div>
			<?php endif; ?>
			<?php if(session('success')): ?>
				<div class="col s12 card-panel green lighten-4 green-text text-darken-4">
					<?php echo e(session('success')); ?>

				</div>
			<?php endif; ?> 
		</div>
		<div class="row">
			<div class="col s6 center-align" id="datos">
				<img src="<?php echo e(asset('images/presupuesto/presupuesto1.jpg')); ?>">
				<div class="vertical"></div>
				<div class="circulo"></div>
				<div class="fs17 mb10 mt10">TUS DATOS</div>
				<div class="linea-inferior"></div>
			</div>
			<div class="col s6 lado gris center-align" id="presupuesto">
				<img src="<?php echo e(asset('images/presupuesto/presupuesto4.jpg')); ?>">
				<div class="vertical"></div>
				<div class="circulo"></div>
				<div class="fs17 mb10 mt10">TU CONSULTA</div>
				<div class="linea-inferior"></div>
			</div>
		</div>
		<?php echo Form::open(['route' => 'presupuesto.enviar', 'method' => 'POST', 'files' => true]); ?>

		<?php echo e(csrf_field()); ?>

		<div class="row">
			<div class="col s12">
				<div class="row" id="estado1">
					<div class="col m6 s12 input-field">
						<?php echo Form::label('nombre','Nombre'); ?>

						<?php echo Form::text('texto', null, ['class' => 'validate']); ?>

					</div>
					<div class="col m6 s12 input-field">
						<?php echo Form::label('localidad','Localidad'); ?>

						<?php echo Form::text('localidad', null, ['class' => 'validate']); ?>

					</div>
					<div class="col m6 s12 input-field">
						<?php echo Form::label('email','E-mail'); ?>

						<?php echo Form::email('email', null, ['class' => 'validate']); ?>

					</div>
					<div class="col m6 s12 input-field">
						<?php echo Form::label('telefono','Teléfono'); ?>

						<?php echo Form::text('telefono', null, ['class' => 'validate']); ?>

					</div>
					<div class="col s12">
						<button type="button" class="waves-effect waves-light btn boton right bg-naranja z-depth-0" id="siguiente">SIGUIENTE</button>
					</div>
				</div>

				<div class="row" id="estado2" style="display: none;">
					<div class="col m6 s12 input-field">
						<?php echo Form::label('mensaje','Mensaje'); ?>

						<?php echo Form::textarea('mensaje', null, ['class'=>'validate materialize-textarea']); ?>

					</div>
					<div class="file-field input-field col s12 m6">
						<div class="btn right bg-naranja boton z-depth-0 centrado" style="margin-top: 6px;">
						    <span>EXAMINAR</span>
						    <?php echo Form::file('archivo'); ?>

						</div>
						<div class="file-path-wrapper">
						    <?php echo Form::text('',null, ['class'=>'file-path validate', 'placeholder' => 'Archivo']); ?>

						</div>
					</div>
					<div class="col m6 offset-m6 s12">
						<button type="submit" class="waves-effect waves-light btn enviar z-depth-0 boton right bg-naranja">ENVIAR</button>
						<button type="button" class="waves-effect waves-light btn atras z-depth-0 boton right" id="atras">ANTERIOR</button>
					</div>
				</div>
			</div>
		</div>
		<?php echo Form::close(); ?>

	</div>
</main>


	<?php echo $__env->make('page.template.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

	<?php echo $__env->make('page.template.scripts', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
	<script>
        $('#siguiente').click(function(event) {
        	if($('input[name=nombre]').val()!=''||$('input[name=localidad]').val()!=''||$('input[name=telefono]').val()!=''||$('input[name=email]').val()!='')
        	{
        		document.getElementById("estado1").className = "animated bounceOutLeft";
                setTimeout(function(){ 
                    $("#estado1").hide('fast', function() {});
                    $("#estado2").show('fast', function() {});
                    document.getElementById("estado2").className = "animated bounceInRight";
                }, 1000);
                $('#presupuesto').removeClass('gris');
                $('#datos').addClass('gris');
        	}
        });

        $('#atras').click(function(event) {
            document.getElementById("estado2").className = "animated bounceOutLeft";
            
            setTimeout(function(){ 
                $("#estado2").hide('fast', function() {}); 
                $("#estado1").show('fast', function() {});
                document.getElementById("estado1").className = "animated bounceInRight";
            }, 1000);
            
            $('#datos').removeClass('gris');
            $('#presupuesto').addClass('gris');
        });

        function animacion(id, clase) {
            $(id).removeClass("animated "+clase).addClass(clase + ' animated').one('webkitAnimationEnd mozAnimationEnd MSAnimationEnd oanimationend animationend', function(){
              $(this).removeClass("animated "+clase);
            });
        };
    </script>
</body>
</html>