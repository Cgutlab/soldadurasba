<!DOCTYPE html>

<html lang="es">



<head>

    <meta charset="utf-8">

    <meta http-equiv="X-UA-Compatible" content="IE=edge">

    <meta name="viewport" content="width=device-width, initial-scale=1">

    <meta name="description" content="">

    <meta name="keyword" content="">

    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <title>Panel de Administrador | <?php echo $__env->yieldContent('titulo'); ?></title>

    <link rel="shortcut icon" href="<?php echo e(asset('favicon.ico')); ?>" type="image/x-icon">

    <link rel="icon" href="<?php echo e(asset('favicon.ico')); ?>" type="image/x-icon">

    <!-- Materialize Core CSS -->

    <link href="<?php echo e(asset('css/materialize/materialize.min.css')); ?>" rel="stylesheet">

    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/admin.css')); ?>">



    <!--Import Google Icon Font-->

    <link href="https://fonts.googleapis.com/css?family=Titillium+Web:300,400,600" rel="stylesheet">

    <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">



</head>

<body>



<!-- Menu derecho -->

<div class="row">

            <div id="nav-mobile" class="side-nav fixed col s3 z-depth-1" style="padding: 0; height: 100%; overflow-y: auto; position: fixed;" role="navigation">

                <img class="responsive-img logo-admin" src="<?php echo e(asset('images/logos/adminlogo.png')); ?>" alt="" width="30%">

                    <ul class="collapsible z-depth-0">

                        <li><a class="collapsible-header waves-effect waves-admin"><i class="material-icons">home</i>Home</a>

                            <div class="collapsible-body">
                                <div class=""><a href="<?php echo e(route('home.slider.create')); ?>">Crear slider</a></div>
                                <div class=""><a href="<?php echo e(route('home.slider.show')); ?>">Editar slider</a></div>
                                <div class=""><a href="<?php echo e(route('home.destacado.show')); ?>">Editar destacados</a></div>
                                <div class=""><a href="<?php echo e(route('homecontenido.edit')); ?>">Editar texto</a></div>
                            </div>

                        </li>

                        <li><a class="collapsible-header waves-effect waves-admin"><i class="material-icons">business</i>Empresa</a>

                            <div class="collapsible-body">

                                <div class=""><a href="<?php echo e(route('empresa.slider.create')); ?>">Crear slider</a></div>
                                <div class=""><a href="<?php echo e(route('empresa.slider.show')); ?>">Editar slider</a></div>
                                <div class=""><a href="<?php echo e(route('empresa.edit')); ?>">Editar contenido</a></div>

                            </div>

                        </li>

                         <li><a class="collapsible-header waves-effect waves-admin"><i class="material-icons">settings</i>Fundición</a>

                            <div class="collapsible-body"> 
                                <div class=""><a href="<?php echo e(route('fundicion.banner.edit')); ?>">Editar portada</a></div>
                                <div class=""><a href="<?php echo e(route('fundicioncontenido.edit')); ?>">Editar texto</a></div>
                                <div class=""><a href="<?php echo e(route('fundicion.create')); ?>">Crear fundición</a></div>
                                <div class=""><a href="<?php echo e(route('fundicion.show')); ?>">Editar fundiciones</a></div>
                            </div>          

                        </li>

                        <li><a class="collapsible-header waves-effect waves-admin"><i class="material-icons">build</i>Piezas terminadas</a>

                            <div class="collapsible-body">              
                                <div class=""><a href="<?php echo e(route('pieza.banner.edit')); ?>">Editar portada</a></div>
                                <div class=""><a href="<?php echo e(route('pieza.create')); ?>">Crear pieza</a></div>
                                <div class=""><a href="<?php echo e(route('pieza.show')); ?>">Editar piezas</a></div>
                            
                            </div>          

                        </li>

                         <li><a class="collapsible-header waves-effect waves-admin"><i class="material-icons">business_center</i>Trabajos realizados</a>

                            <div class="collapsible-body">              
                                <div class=""><a href="<?php echo e(route('trabajo.banner.edit')); ?>">Editar portada</a></div>
                                <div class=""><a href="<?php echo e(route('trabajo.create')); ?>">Crear trabajo</a></div>
                                <div class=""><a href="<?php echo e(route('trabajo.show')); ?>">Editar trabajos</a></div>
                            
                            </div>          

                        </li>

                         <li><a class="collapsible-header waves-effect waves-admin"><i class="material-icons">people</i>Clientes</a>

                            <div class="collapsible-body">              
                                <div class=""><a href="<?php echo e(route('cliente.banner.edit')); ?>">Editar portada</a></div>
                                <div class=""><a href="<?php echo e(route('clientecontenido.edit')); ?>">Editar contenido</a></div>
                                <div class=""><a href="<?php echo e(route('cliente.create')); ?>">Crear cliente</a></div>
                                <div class=""><a href="<?php echo e(route('cliente.show')); ?>">Editar clientes</a></div>
                            </div>          

                        </li>

                         <li><a class="collapsible-header waves-effect waves-admin"><i class="material-icons">beenhere</i>Calidad</a>

                            <div class="collapsible-body">             
                                <div class=""><a href="<?php echo e(route('calidad.banner.edit')); ?>">Editar portada</a></div>
                                <div class=""><a href="<?php echo e(route('calidad.edit')); ?>">Editar contenido</a></div>
                            </div>          

                        </li>



                        <li><a class="collapsible-header waves-effect waves-admin"><i class="material-icons">message</i>Contacto</a>

                            <div class="collapsible-body">              
                               <div class=""><a href="<?php echo e(route('contacto.edit')); ?>">Términos y condiciones</a></div>
                            </div>          

                        </li>


                        <li><a class="collapsible-header waves-effect waves-admin"><i class="material-icons">thumb_up</i>Redes sociales</a>

                            <div class="collapsible-body">              

                                <div class=""><a href="<?php echo e(route('redes.create')); ?>">Crear red social</a></div>

                                <div class=""><a href="<?php echo e(route('redes.index')); ?>">Editar red social</a></div>

                            </div>          

                        </li>
                  
                        <li><a class="collapsible-header waves-effect waves-admin"><i class="material-icons">collections</i>Logos</a>  

                            <div class="collapsible-body">            

                                <div class=""><a href="<?php echo e(route('logos.index')); ?>">Editar logos</a>

                            </div>

                        </li>

                        <li><a class="collapsible-header waves-effect waves-admin"><i class="tiny material-icons">view_headline</i>Datos de la empresa</a>

                            <div class="collapsible-body"> 

                                <div class=""><a href="<?php echo e(route('datos.index')); ?>">Editar datos</a></div>

                            </div>

                        </li>

                        <li><a class="collapsible-header waves-effect waves-admin"><i class="material-icons">pin_drop</i>Metadatos</a>

                            <div class="collapsible-body">

                                <div class=""><a href="<?php echo e(route('metadatos.index')); ?>">Editar metadatos</a></div>

                            </div>

                        </li>                

                         <li><a class="collapsible-header waves-effect waves-admin"><i class="material-icons">account_circle</i>Usuarios</a>

                            <div class="collapsible-body">

                                <div class=""><a href="<?php echo e(route('usuarios.create')); ?>">Crear usuario</a></div>

                                <div class=""><a href="<?php echo e(route('usuarios.index')); ?>">Editar usuario</a></div>

                            </div>

                        </li>

                    </ul>

            </div>



    <div id="page-wrapper">

        <nav class="z-depth-0 col s9 push-s3" style="padding: 0;">

            <div class="nav-wrapper nave ">

                <ul class="hide-on-med-and-down" style="margin: 0 10%;">

                    <li> <?php echo $__env->yieldContent('titulo'); ?> </li>

                    <li class="right"><a class="dropdown-trigger" href="<?php echo e(route('adm.logout')); ?>" data-target="dropdown1">Cerrar Sesión</a></li>

                </ul>

            </div>

        </nav>

            <div class="col s9 push-s3" style="padding: 40px;">

                <?php echo $__env->yieldContent('cuerpo'); ?>

            </div>                             

    </div>

</div>

    <!-- /#wrapper -->

    <!-- jQuery -->

    <script src="<?php echo e(asset('js/jquery.min.js')); ?>"></script>



    <!-- Materialize Core JavaScript -->

    <script src="<?php echo e(asset('js/materialize/materialize.min.js')); ?>"></script>



    <script type="text/javascript">

    $(document).ready(function()

    {

        $('.collapsible').collapsible();

        $('select').material_select();

    });

    </script>

     <script type="text/javascript">
        $('.confirmar').click(function(event) {
            if(!confirm('¿Esta seguro que desea borrar este elemento?'))
            {
                event.preventDefault();
            }
        });
    </script>

</body>

</html>



