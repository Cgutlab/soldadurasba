<script type="text/javascript" src="<?php echo e(asset('js/jquery.min.js')); ?>"></script>

<script type="text/javascript" src="<?php echo e(asset('js/materialize/materialize.min.js')); ?>"></script>

<script>
 $(document).ready(function(){
    $('.sidenav').sideNav();
  });
</script>       

